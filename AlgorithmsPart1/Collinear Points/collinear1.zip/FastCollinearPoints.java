import java.util.Arrays;

public class FastCollinearPoints {
    private LineSegment[] segments;
    private int size;
    
    public FastCollinearPoints(Point[] points){
        if (points == null) throw new java.lang.IllegalArgumentException(); 
        for (int i = 0; i < points.length-1; i++) {
            if (points[i] == null) throw new java.lang.IllegalArgumentException();
            for (int j = i+1; j < points.length; j++) {
                if (points[j] == null) throw new java.lang.IllegalArgumentException();
                if (points[i].compareTo(points[j]) == 0) throw new java.lang.IllegalArgumentException();
            }
        }
        
        size = 0;
        LineSegment[] tempLineSegment = new LineSegment[points.length];
        
        for (int i = 0; i < points.length - 1; i++) {
            Arrays.sort(points, i+1, points.length, points[i].slopeOrder());
            
            double slope = points[i].slopeTo(points[i+1]);
            int numberOfConsecutivePoints = 2;
            
            for (int j = i+2; j < points.length; j++) {
                if (points[i].slopeTo(points[j]) == slope) {
                    numberOfConsecutivePoints++;
                } else {
                    if (numberOfConsecutivePoints >= 4) {
                        tempLineSegment[size++] = new LineSegment(points[i], points[j-1]);
                    }
                    slope = points[i].slopeTo(points[j]);
                    numberOfConsecutivePoints = 1;
                }
            }
        }
        
        segments = new LineSegment[size];
        for (int i = 0; i < size; i++) {
            segments[i] = tempLineSegment[i];
        }
    }
    
    public int numberOfSegments() {
        return size;
    }
    
    public LineSegment[] segments() {
        return segments;
    }
}