import java.util.Comparator;
import java.util.Stack;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.In;

public class Solver {
    
    private Node endNode;
    private boolean solvable;
    
    private class Node {
        private final Board board;
        private final Node parent;
        
        public Node(Board board, Node parent) {
            this.board = board;
            this.parent = parent;
        }
    }
    
    public Solver(Board initial) {
        Comparator<Node> nodeComparator = new Comparator<Node>() {
            public int compare(Node a, Node b) {
                return a.board.manhattan() + numOfMoves(a) - b.board.manhattan() - numOfMoves(b);
            }
        };
        MinPQ<Node> pq;
        MinPQ<Node> pqSwap;
        pq = new MinPQ<Node>(nodeComparator);
        pqSwap = new MinPQ<Node>(nodeComparator);
        
        pq.insert(new Node(initial, null));
        pqSwap.insert(new Node(initial.twin(), null));
        
        solvable = false;
        
        Node node = pq.delMin();
        Node nodeSwap = pqSwap.delMin();
        
        while (!node.board.isGoal() && !nodeSwap.board.isGoal()) {
            
            for (Board b: node.board.neighbors()) {
                if (node.parent == null || !b.equals(node.parent.board)) {
                    pq.insert(new Node(b, node));
                }
            }
            
            for (Board b: nodeSwap.board.neighbors()) {
                if (nodeSwap.parent == null || !b.equals(nodeSwap.parent.board)) {
                    pqSwap.insert(new Node(b, nodeSwap));
                }
            }
            
            node = pq.delMin();
            nodeSwap = pqSwap.delMin(); 
        }
        
        if (node.board.isGoal()) {
            solvable = false;
            endNode = node;
        }
    }
    
    public boolean isSolvable() {
        return solvable;
    }
    
    public int moves() {
        if (!solvable) return -1;
        
        Node last = endNode;
        int moves = 0;
        while (last.parent != null) {
            moves++;
            last = last.parent;
        }
        
        return moves;
    }
    
    public Iterable<Board> solution() {
        Stack<Board> solution = new Stack<Board>();
        Node last = endNode;
        solution.push(last.board);
        
        while (last.parent != null) {
            last = last.parent;
            solution.push(last.board);
        }
        return solution;
    }
    
    private int numOfMoves(Node node) {
        int moves = 0;
        while (node.parent != null) {
            moves++;
        }
        return moves;
    }
    
    public static void main(String[] args) {
        
        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] blocks = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
            blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);
        
        // solve the puzzle
        Solver solver = new Solver(initial);
        
        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }
}